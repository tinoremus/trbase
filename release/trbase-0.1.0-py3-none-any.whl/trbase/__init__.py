__add__ = ['std', 'pyqtwidgets']
